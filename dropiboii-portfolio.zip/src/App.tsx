/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Bot, 
  Server, 
  Wallet, 
  Cpu, 
  Globe, 
  Terminal as TerminalIcon, 
  MessageSquare, 
  Zap, 
  ExternalLink, 
  Mail,
  ChevronRight,
  Database,
  Lock,
  Layout,
  HardDrive
} from 'lucide-react';

// --- Types ---

type Tab = 'OVERVIEW' | 'DISCORD' | 'MINECRAFT' | 'CRYPTOPAY';

// --- Components ---

const LoadingScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 800);
          return 100;
        }
        return prev + 2;
      });
    }, 30);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black"
    >
      <div className="relative w-64 h-2 bg-white/10 rounded-full overflow-hidden">
        <motion.div
          className="absolute inset-y-0 left-0 bg-neon-cyan shadow-[0_0_15px_rgba(0,242,255,0.8)]"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
        />
      </div>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mt-6 font-mono text-neon-cyan text-sm tracking-[0.2em]"
      >
        ESTABLISHING SECURE CONNECTION... {progress}%
      </motion.p>
      
      {/* CSS Animated data nodes */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ y: -100, opacity: 0 }}
            animate={{ 
              y: [null, window.innerHeight + 100],
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: Math.random() * 3 + 2, 
              repeat: Infinity,
              delay: Math.random() * 2 
            }}
            className="absolute h-px w-px bg-neon-cyan shadow-[0_0_10px_rgba(0,242,255,1)]"
            style={{ left: `${Math.random() * 100}%` }}
          />
        ))}
      </div>
    </motion.div>
  );
};

const Navbar = ({ activeTab, setActiveTab }: { activeTab: Tab, setActiveTab: (t: Tab) => void }) => {
  const tabs: Tab[] = ['OVERVIEW', 'DISCORD', 'MINECRAFT', 'CRYPTOPAY'];

  return (
    <nav className="fixed top-8 left-1/2 -translate-x-1/2 z-40">
      <div className="glass-card px-2 py-2 flex items-center gap-1">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-xl text-xs font-display font-medium tracking-wider transition-all duration-300 ${
              activeTab === tab 
                ? 'bg-white/10 text-neon-cyan shadow-[inset_0_0_10px_rgba(255,255,255,0.1)]' 
                : 'text-white/60 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab === 'CRYPTOPAY' ? 'THE VAULT' : tab}
          </button>
        ))}
      </div>
    </nav>
  );
};

const StatCard = ({ label, value, icon: Icon, colorClass }: { label: string, value: string, icon: any, colorClass: string }) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="glass-card p-6 flex flex-col gap-4 border-l-4 border-l-transparent hover:border-l-current transition-all"
    style={{ borderColor: colorClass.includes('cyan') ? 'var(--color-neon-cyan)' : colorClass.includes('green') ? 'var(--color-neon-green)' : 'var(--color-neon-purple)' }}
  >
    <div className={`p-3 rounded-xl w-fit bg-white/5 ${colorClass}`}>
      <Icon size={24} />
    </div>
    <div>
      <h3 className="text-2xl font-display font-bold tracking-tight">{value}</h3>
      <p className="text-white/50 text-xs uppercase tracking-widest mt-1">{label}</p>
    </div>
  </motion.div>
);

const ProgressBar = ({ label, percent, color }: { label: string, percent: number, color: string }) => (
  <div className="space-y-2">
    <div className="flex justify-between text-xs font-mono tracking-wider">
      <span className="text-white/70 uppercase">{label}</span>
      <span style={{ color }}>{percent}%</span>
    </div>
    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        whileInView={{ width: `${percent}%` }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="h-full"
        style={{ backgroundColor: color, boxShadow: `0 0 10px ${color}` }}
      />
    </div>
  </div>
);

const SectionHeader = ({ title, subtitle, colorClass }: { title: string, subtitle: string, colorClass: string }) => (
  <div className="mb-12">
    <motion.h2 
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className={`text-4xl md:text-5xl font-display font-bold mb-4 uppercase italic ${colorClass}`}
    >
      {title}
    </motion.h2>
    <motion.p 
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay: 0.1 }}
      className="text-white/60 max-w-2xl text-lg leading-relaxed"
    >
      {subtitle}
    </motion.p>
  </div>
);

const FeatureCard = ({ title, desc, icon: Icon, colorClass }: { title: string, desc: string, icon: any, colorClass: string }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="glass-card p-8 group relative overflow-hidden"
  >
    <div className={`absolute top-0 right-0 w-32 h-32 blur-3xl opacity-10 group-hover:opacity-20 transition-opacity ${colorClass.replace('text-', 'bg-')}`} />
    <div className={`p-4 rounded-2xl w-fit bg-white/5 mb-6 ${colorClass}`}>
      <Icon size={28} />
    </div>
    <h4 className="text-xl font-display font-bold mb-3">{title}</h4>
    <p className="text-white/50 text-sm leading-relaxed">{desc}</p>
  </motion.div>
);

// --- Main App ---

export default function App() {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('OVERVIEW');
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    // Show toast after a delay
    if (!loading) {
      const timer = setTimeout(() => setShowToast(true), 2000);
      return () => clearTimeout(timer);
    }
  }, [loading]);

  return (
    <div className="relative min-h-screen bg-grid overflow-x-hidden">
      <AnimatePresence>
        {loading && <LoadingScreen onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {!loading && (
        <>
          <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

          <main className="container mx-auto px-6 py-32 space-y-32">
            
            {/* HERO SECTION */}
            <section id="hero" className="flex flex-col items-center text-center py-20 relative">
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative mb-12"
              >
                {/* Rotating holographic tech symbol */}
                <div className="w-48 h-48 md:w-64 md:h-64 relative flex items-center justify-center">
                  <div className="absolute inset-0 border-2 border-neon-cyan/20 rounded-full animate-spin-slow" />
                  <div className="absolute inset-4 border border-neon-purple/20 rounded-full animate-spin-slow [animation-direction:reverse]" />
                  <div className="absolute inset-8 border-2 border-neon-cyan/40 rounded-full animate-pulse-glow text-neon-cyan flex items-center justify-center">
                    <Cpu size={64} className="animate-float" />
                  </div>
                  <div className="absolute -inset-2 bg-neon-cyan/5 blur-2xl rounded-full" />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="space-y-6 max-w-4xl"
              >
                <h1 className="text-7xl md:text-9xl font-display font-bold italic tracking-tighter neon-text-cyan leading-none">
                  DROPIBOII
                </h1>
                <p className="text-white/80 font-display text-lg md:text-2xl uppercase tracking-[0.3em] font-light">
                  Elite Infrastructure Architect | <span className="text-neon-purple">Secure Bot Developer</span> | Server DevOps
                </p>
                <div className="pt-4">
                  <p className="glass-card px-8 py-4 inline-block text-white/90 text-sm md:text-base border-white/20">
                    "Building highly scalable Discord Bots & <span className="text-neon-green">lag-free Minecraft Networks</span> that communities love."
                  </p>
                </div>
              </motion.div>
            </section>

            {/* CONTENT SECTIONS */}
            <AnimatePresence mode="wait">
              {/* OVERVIEW SECTION */}
              {activeTab === 'OVERVIEW' && (
                <motion.div
                  key="overview"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-32"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard label="Network Uptime" value="99.9%" icon={Zap} colorClass="text-neon-cyan" />
                    <StatCard label="Bot Users Handled" value="100K+" icon={Bot} colorClass="text-neon-purple" />
                    <StatCard label="Stable TPS (MC)" value="20.0" icon={Server} colorClass="text-neon-green" />
                    <StatCard label="Security Breaches" value="ZERO" icon={Shield} colorClass="text-neon-gold" />
                  </div>

                  <div className="glass-card p-12 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-neon-cyan via-neon-purple to-neon-green" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                      <div className="space-y-8">
                        <div>
                          <h3 className="text-3xl font-display font-bold mb-4 uppercase italic">Technical Stack Mastery</h3>
                          <p className="text-white/50 leading-relaxed">
                            A multi-disciplinary approach to digital infrastructure, combining low-latency backends with high-security integrations.
                          </p>
                        </div>
                        <div className="space-y-6">
                          <ProgressBar label="Python (Advanced Architectures)" percent={95} color="var(--color-neon-cyan)" />
                          <ProgressBar label="Node.js (Real-time Systems)" percent={85} color="var(--color-neon-purple)" />
                          <ProgressBar label="Linux & VPS DevOps" percent={98} color="var(--color-neon-green)" />
                          <ProgressBar label="Minecraft Engine Optimization" percent={90} color="var(--color-neon-gold)" />
                        </div>
                      </div>
                      <div className="relative aspect-square flex items-center justify-center">
                         <div className="glass-card p-1 w-full max-w-sm aspect-square bg-gradient-to-br from-white/10 to-transparent border-white/5 flex items-center justify-center group overflow-hidden">
                            <TerminalIcon size={120} className="text-white/20 group-hover:text-neon-cyan transition-colors group-hover:scale-110 duration-700" />
                            <div className="absolute inset-0 flex flex-col justify-center items-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/80 backdrop-blur-sm p-6 text-center space-y-4">
                              <p className="font-mono text-xs text-neon-cyan">{">"} Loading expert modules...</p>
                              <p className="font-sans text-xs text-white/70 italic">"Security is not a feature, it's the foundation."</p>
                            </div>
                         </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* DISCORD SECTION */}
              {activeTab === 'DISCORD' && (
                <motion.div
                  key="discord"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-16"
                >
                  <SectionHeader 
                    title="Discord Bot Development" 
                    subtitle="I build secure, high-performance, and custom-tailored Discord bots designed to handle massive communities without downtime."
                    colorClass="neon-text-cyan"
                  />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <FeatureCard 
                      title="Custom Architectures" 
                      desc="Fully custom, no-prefix & case-insensitive command systems built for speed and accessibility." 
                      icon={Layout} 
                      colorClass="text-neon-cyan"
                    />
                    <FeatureCard 
                      title="Advanced Economy" 
                      desc="Robust database management systems with multi-tiered ticket support and complex economic loops." 
                      icon={Database} 
                      colorClass="text-neon-purple"
                    />
                    <FeatureCard 
                      title="High-Security Mod" 
                      desc="Dynamic voice channel management and high-security moderation tools with raid protection." 
                      icon={Shield} 
                      colorClass="text-neon-cyan"
                    />
                  </div>
                </motion.div>
              )}

              {/* MINECRAFT SECTION */}
              {activeTab === 'MINECRAFT' && (
                <motion.div
                  key="minecraft"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-16"
                >
                  <SectionHeader 
                    title="Minecraft Infrastructure" 
                    subtitle="Stop losing players to lag. I engineer optimized, cross-platform SMP networks that scale effortlessly."
                    colorClass="neon-text-green"
                  />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <FeatureCard 
                      title="Cross-Play Mastery" 
                      desc="GeyserMC & Floodgate integration for flawless Java & Bedrock cross-play environments." 
                      icon={Globe} 
                      colorClass="text-neon-green"
                    />
                    <FeatureCard 
                      title="Proxy & Anti-Cheat" 
                      desc="Velocity/BungeeCord proxy networks coupled with advanced server-side anti-cheat systems." 
                      icon={Zap} 
                      colorClass="text-neon-gold"
                    />
                    <FeatureCard 
                      title="VPS Deployment" 
                      desc="Complete Linux setup, Pterodactyl Wings configuration, and dedicated node optimization." 
                      icon={HardDrive} 
                      colorClass="text-neon-green"
                    />
                  </div>
                </motion.div>
              )}

              {/* CRYPTOPAY SECTION */}
              {activeTab === 'CRYPTOPAY' && (
                <motion.div
                  key="cryptopay"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-16"
                >
                  <SectionHeader 
                    title="The CryptoPay Vault" 
                    subtitle="A testament to my development capabilities. I architected and coded this Bank-Grade Web3 Discord Wallet from scratch."
                    colorClass="neon-text-purple"
                  />
                  
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                    <div className="lg:col-span-5 space-y-8">
                      <div className="glass-card p-6 border-neon-purple/20 relative group">
                        <div className="absolute -top-3 -right-3 px-3 py-1 bg-neon-purple text-black text-[10px] font-bold uppercase rounded-md shadow-[0_0_15px_rgba(188,19,254,0.5)]">
                          100% Solo Developed
                        </div>
                        <div className="flex items-center gap-4 mb-6">
                           <div className="p-3 bg-neon-purple/10 rounded-xl text-neon-purple">
                             <Wallet size={32} />
                           </div>
                           <div>
                             <h4 className="text-xl font-display font-bold">Web3 Gateway</h4>
                             <p className="text-xs text-white/40 uppercase tracking-widest font-mono">Status: Production Ready</p>
                           </div>
                        </div>
                        <ul className="space-y-4">
                          {[
                            "Zero-Fee Internal Tipping",
                            "Community Airdrop Machine",
                            "Instant Multi-Chain Transfers",
                            "Secure API Vault Integration"
                          ].map((item, i) => (
                            <li key={i} className="flex items-center gap-3 text-sm text-white/70">
                              <ChevronRight size={16} className="text-neon-purple" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="lg:col-span-7">
                      <div className="bg-[#050508] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                        <div className="bg-white/5 px-6 py-3 flex items-center justify-between border-b border-white/5">
                           <div className="flex gap-2">
                             <div className="w-3 h-3 rounded-full bg-red-500/50" />
                             <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                             <div className="w-3 h-3 rounded-full bg-green-500/50" />
                           </div>
                           <p className="text-[10px] font-mono text-white/30 uppercase tracking-[0.2em]">vault_engine_v1.0.exe</p>
                        </div>
                        <div className="p-8 font-mono text-sm space-y-2">
                          <p className="text-neon-green"> {`> System: CryptoPay Engine Online (Secure)`} </p>
                          <p className="text-white/60"> {`> $register — Create encrypted vault`} </p>
                          <p className="text-white/60"> {`> $bal — Check live portfolio`} </p>
                          <p className="text-white/60"> {`> $tip @user 100 BNB — Instant secure transfer`} </p>
                          <motion.div 
                            animate={{ opacity: [1, 0, 1] }} 
                            transition={{ duration: 0.8, repeat: Infinity }}
                            className="w-2 h-5 bg-neon-purple inline-block align-middle ml-1" 
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* CALL TO ACTION */}
            <section id="contact" className="py-20 flex flex-col items-center">
              <div className="glass-card p-1 md:p-2 rounded-[2rem] w-full max-w-5xl">
                <div className="bg-white/5 rounded-[1.8rem] p-12 md:p-20 text-center space-y-10 relative overflow-hidden">
                   <div className="absolute top-0 right-0 w-64 h-64 bg-neon-cyan/5 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2" />
                   <div className="absolute bottom-0 left-0 w-64 h-64 bg-neon-purple/5 blur-3xl rounded-full translate-y-1/2 -translate-x-1/2" />
                   
                   <div className="space-y-4 relative">
                     <h2 className="text-4xl md:text-6xl font-display font-bold uppercase italic italic tracking-tight">
                       Ready to Build <span className="neon-text-cyan">Something Incredible?</span>
                     </h2>
                     <p className="text-white/50 text-lg md:text-xl max-w-2xl mx-auto">
                       Available for freelance projects, custom bot development, and server configurations. Let's engineer the future of your community.
                     </p>
                   </div>

                   <div className="flex flex-col items-center gap-8 relative">
                     <div className="flex items-center gap-3 px-6 py-3 glass-card text-white/70 text-sm font-mono border-white/10">
                       <Mail size={18} className="text-neon-cyan" />
                       dropiboiiz@gmail.com
                     </div>

                     <motion.a 
                        href="https://discord.com/users/dropiboii"
                        target="_blank"
                        rel="noopener noreferrer"
                        whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(0,242,255,0.4)" }}
                        whileTap={{ scale: 0.95 }}
                        className="bg-neon-cyan text-black px-12 py-5 rounded-2xl font-display font-bold text-xl uppercase tracking-widest transition-all duration-300 shadow-[0_0_20px_rgba(0,242,255,0.2)] flex items-center gap-3 group"
                     >
                       HIRE ME / DM ON DISCORD
                       <MessageSquare size={24} className="group-hover:translate-x-1 transition-transform" />
                     </motion.a>
                   </div>
                </div>
              </div>
            </section>

          </main>

          {/* Footer Footer */}
          <footer className="container mx-auto px-6 py-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 glass-card flex items-center justify-center text-neon-cyan">
                 <TerminalIcon size={20} />
               </div>
               <span className="font-display font-bold tracking-widest text-lg neon-text-cyan">DROPIBOII</span>
            </div>
            <p className="text-white/20 text-xs font-mono uppercase tracking-widest">
              © 2026 DROPIBOII INFRASTRUCTURE ARCHITECT. ALL RIGHTS SECURED.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-white/30 hover:text-neon-cyan transition-colors"><ExternalLink size={20} /></a>
              <a href="#" className="text-white/30 hover:text-neon-purple transition-colors"><Globe size={20} /></a>
            </div>
          </footer>

          {/* Toast Notification */}
          <AnimatePresence>
            {showToast && (
              <motion.div
                initial={{ x: 300, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 300, opacity: 0 }}
                className="fixed bottom-8 right-8 z-50 glass-card p-4 flex items-center gap-4 border-l-4 border-neon-green/50 animate-pulse-glow"
              >
                <div className="w-2 h-2 rounded-full bg-neon-green shadow-[0_0_10px_#39ff14]" />
                <div className="flex flex-col">
                  <p className="text-xs font-display font-bold tracking-wider uppercase">Status: Available for Work</p>
                  <p className="text-[10px] text-white/50 font-mono">Ping me on Discord!</p>
                </div>
                <button 
                  onClick={() => setShowToast(false)}
                  className="ml-2 p-1 hover:bg-white/10 rounded-md text-white/30 hover:text-white transition-colors"
                >
                  <Lock size={14} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </div>
  );
}

